## Arducam_MINI_2MP_Plus_Videostreaming 
### connection table
|  CAMERA   | PICO  |
|  :----:  | :----:  |
| SCL  | 9 |
| SDA  | 8 |
| VCC  | VCC |
| GND  | GND |
| SCK  | 2 |
| MISO | 4 |
| MOSI | 3 |
| CS  | 5 |
