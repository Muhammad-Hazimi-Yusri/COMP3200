import usb_cdc
usb_cdc.enable(data=True)
